<footer class="footer mt-auto footer-light">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6 small">Copyright &#xA9; Centre for Health Solutions-Kenya 2022</div>
            <div class="col-md-6 text-md-right small">
                <a href="#">Privacy Policy</a>
                &#xB7;
                <a href="#">Terms &amp; Conditions</a>
            </div>
        </div>
    </div>
</footer>
